# Task 3: Logbook

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
- [x] g.
- [x] h.
- [x] i.

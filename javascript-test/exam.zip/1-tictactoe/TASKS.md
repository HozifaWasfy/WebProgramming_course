# Task 1 - Tic-tac-toe

- [ X] a.
- [ X] b.
- [ X] c.
- [ X] d.

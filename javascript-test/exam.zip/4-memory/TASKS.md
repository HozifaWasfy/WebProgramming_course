# Task 4 - Memory

- [X] a.
- [X] b.
- [X] c.
- [X] d.
- [ ] e.
- [X] f.
- [ ] g.

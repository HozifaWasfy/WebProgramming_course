# Task 2 - Savings

- [X] a.
- [X] b.
- [X] c.
- [X] d.
